import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useState } from 'react';
import Navbar from './components/Home/Navbar/Navbar';
import Hero from './components/Home/Hero/Hero';
import Job from './components/Home/Job/Job';
import Search from './components/Home/Search/Search';
import Testimonials from './components/Home/Testimonials/Testimonials';
import Footer from './components/Home/Footer/Footer';
import Jhero from './components/Jobs/Jhero';
import Jobsection from './components/Jobs/Jobsection/Jobsection';
import FilterComponent from './components/Jobs/Filter/FilterComnents';
import TopCompanies from './components/Jobs/TopCompanies/TopCompanies';
import Hworks from './components/About/Hworks';
import CollapsibleFAQ from './components/About/Collapse/Collapsible';
import ContactSection from './components/Contact/ContactSection/ContactSection';

const mockJobs = [
  {
    id: 1,
    title: 'Frontend Developer',
    company: 'Tech Corp',
    location: 'New York',
    type: 'Full Time',
    experience: 'Intermediate',
    salary: 85000,
    postedDate: '2 days ago',
    categories: ['telecommunications']
  },
  // Add more job objects...
];

function App() {
  const [jobs, setJobs] = useState(mockJobs);
  const [filteredJobs, setFilteredJobs] = useState(mockJobs);

  const handleFilterChange = (filters) => {
    const filtered = mockJobs.filter(job => {
      if (filters.searchTerm && 
          !job.title.toLowerCase().includes(filters.searchTerm.toLowerCase()) &&
          !job.company.toLowerCase().includes(filters.searchTerm.toLowerCase())) {
        return false;
      }
      
      if (filters.location && job.location.toLowerCase() !== filters.location) {
        return false;
      }
      
      if (filters.categories.length > 0 && 
          !filters.categories.some(cat => job.categories.includes(cat))) {
        return false;
      }
      
      if (filters.jobTypes.length > 0 && 
          !filters.jobTypes.includes(job.type.toLowerCase().replace(/\s+/g, '-'))) {
        return false;
      }
      
      if (filters.experienceLevels.length > 0 && 
          !filters.experienceLevels.includes(job.experience.toLowerCase().replace(/\s+/g, '-'))) {
        return false;
      }
      
      if (job.salary < filters.salaryRange[0] || job.salary > filters.salaryRange[1]) {
        return false;
      }
      
      return true;
    });
    setFilteredJobs(filtered);
  };

  return (
    <Router>
      <Navbar />
      <Routes>
        <Route
          path="/"
          element={
            <>
              <Hero />
              <Job />
              <Search />
              <Testimonials />
            </>
          }
        />
          <Route
          path="/jobs"
          element={
            <>
              <Jhero heading="Jobs" />
              <div className="container my-4">
                <div className="row">
                  <div className="col-md-4 mb-4">
                    <FilterComponent onFilterChange={handleFilterChange}/>
                  </div>
                  <div className="col-md-8">
                    <Job extraClass="custom-margin" jobs={filteredJobs} />
                  </div>
                </div>
              </div>
              <TopCompanies/>
            </>
          }
        />
        <Route
          path="/about"
          element={
            <>
              <Jhero heading="About us"/>
              <Hworks/>
              <CollapsibleFAQ/>
            </>
          }
        />
        <Route
          path="/contact"
          element={
            <>
              <Jhero heading="Contact"/>
              <ContactSection/>
            </>
          }
        />
      
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;






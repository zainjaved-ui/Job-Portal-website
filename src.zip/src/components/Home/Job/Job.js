import React from 'react';
import JobCard from './JobCard';
import img1 from './img1.jpeg'; // your image path

export default function Job({ extraClass = "" }) {
  const jobList = [
    {
      postedAt: '10 min ago',
    title: 'Forward Security Director',
    company: 'Bauch, Schuppe and Schulist Co',
    category: 'Hotels & Tourism',
    type: 'Full time',
    salary: '$40000–$42000',
    location: 'New York, USA',
    logo: img1 // use real image path
    },
    {
      postedAt: '10 min ago',
    title: 'Forward Security Director',
    company: 'Bauch, Schuppe and Schulist Co',
    category: 'Hotels & Tourism',
    type: 'Full time',
    salary: '$40000–$42000',
    location: 'New York, USA',
    logo: img1 // use real image path
    },
    {
      postedAt: '10 min ago',
    title: 'Forward Security Director',
    company: 'Bauch, Schuppe and Schulist Co',
    category: 'Hotels & Tourism',
    type: 'Full time',
    salary: '$40000–$42000',
    location: 'New York, USA',
    logo: img1 // use real image path
    },
    {
      postedAt: '10 min ago',
    title: 'Forward Security Director',
    company: 'Bauch, Schuppe and Schulist Co',
    category: 'Hotels & Tourism',
    type: 'Full time',
    salary: '$40000–$42000',
    location: 'New York, USA',
    logo: img1 // use real image path
    },
  ];

  return (
    <>
        <div className={`recent-jobs-header ${extraClass}`}>
            <h2 className="section-title">Recent Jobs Available</h2>
            <button className="view-all-btn">View All</button>
        </div>
            {jobList.map((job) => (
                <JobCard key={job.id} job={job} />
            ))}
    </>
  );
}

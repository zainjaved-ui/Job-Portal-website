import React from 'react';
import './Hero.css'; // custom styles
import { FaBriefcase, FaUsers, FaBuilding } from 'react-icons/fa';

export default function Home() {
  return (
    <div className="home-container">
      {/* Headline */}
      <h1 className="main-heading">Find Your Dream Job Today!</h1>
      <p className="sub-text">Connecting Talent with Opportunity: Your Gateway to Career Success</p>

      {/* Search Bar */}
      <div className="search-bar d-flex">
        <select className="form-select search-input">
          <option>Job Title</option>
          <option>Frontend Developer</option>
          <option>Backend Developer</option>
          <option>UI/UX Designer</option>
        </select>
        <select className="form-select search-input">
          <option>Location</option>
          <option>Lahore</option>
          <option>Karachi</option>
          <option>Islamabad</option>
        </select>
        <select className="form-select search-input">
          <option>Category</option>
          <option>Full-time</option>
          <option>Part-time</option>
          <option>Remote</option>
        </select>
        <button className="btn search-btn">Search</button>
      </div>

      {/* Stats */}
      <div className="stats d-flex justify-content-center">
            <div className="stat-box d-flex align-items-center">
                <div className="icon-circle">
                <FaBriefcase size={20} />
                </div>
                <div className="stat-text">
                <h4>1200+</h4>
                <p>Total Jobs</p>
                </div>
            </div>

            <div className="stat-box d-flex align-items-center">
                <div className="icon-circle">
                <FaUsers size={20} />
                </div>
                <div className="stat-text">
                <h4>800+</h4>
                <p>Candidates</p>
                </div>
            </div>

            <div className="stat-box d-flex align-items-center">
                <div className="icon-circle">
                <FaBuilding size={20} />
                </div>
                <div className="stat-text">
                <h4>300+</h4>
                <p>Companies</p>
                </div>
            </div>
        </div>  
    </div>
  );
}

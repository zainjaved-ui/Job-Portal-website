import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

export default function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg glass-navbar navbar-dark">
      <div className="container-fluid">
        {/* Left: Logo */}
        <Link className="navbar-brand text-white" to="/">JobHunt</Link>

        {/* Navbar toggler (for mobile) */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Center: Nav Links */}
        <div className="collapse navbar-collapse justify-content-center" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link text-white" to="/">Home</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/jobs">Jobs</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/about">About</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/contact">Contact</Link>
            </li>
            {/* Mobile-only Auth Buttons */}
            <li className="nav-item d-lg-none">
              <button className="btn text-white w-100 text-start  ps-3 border border-white">Login</button>
            </li>
            <li className="nav-item d-lg-none">
              <button className="btn text-white btn-lightt w-100 text-start ps-3">Register</button>
            </li>

          </ul>
        </div>

        {/* Right: Login/Register */}
        <div className="d-flex desktop-auth-buttons">
          <button className="btn text-white btn-lg me-2">Login</button>
          <button className="btn text-white btn-lightt">Register</button>
        </div>
      </div>
    </nav>
  );
}
